
# Role-Based Access Control (RBAC) System

This project implements an authentication and role-based access control (RBAC) system in Java using Spring Boot and JWT.

## Features
- Secure authentication (registration, login, and logout).
- Role-based access control for `Admin`, `User`, and `Moderator` roles.
- JWT-based session management.
- Password hashing for secure storage.

## Requirements
- Java 11 or higher
- Maven
- H2 (in-memory database) or MySQL/PostgreSQL

## Installation and Setup
1. Clone the repository or unzip the project folder.
2. Configure the database in `src/main/resources/application.properties`:
   ```properties
   spring.datasource.url=jdbc:h2:mem:rbac
   spring.datasource.driver-class-name=org.h2.Driver
   spring.jpa.hibernate.ddl-auto=update
   spring.h2.console.enabled=true
   spring.h2.console.path=/h2-console
   spring.datasource.username=sa
   spring.datasource.password=password
   ```

3. Build and run the project:
   ```
   mvn spring-boot:run
   ```

4. Access the application at `http://localhost:8080`.

## Endpoints
### Authentication
- `POST /api/auth/register` - Register a new user.
- `POST /api/auth/login` - Log in and retrieve a JWT token.

### Role-Based Routes
- `GET /admin/dashboard` - Admin-only access.
- More routes can be added based on roles.

## Testing
You can test the application using tools like Postman or cURL:
1. Register a user:
   ```
   POST http://localhost:8080/api/auth/register
   Body: { "username": "user1", "password": "password123" }
   ```
2. Log in to get a JWT token:
   ```
   POST http://localhost:8080/api/auth/login
   Body: { "username": "user1", "password": "password123" }
   ```
3. Use the token to access protected routes:
   ```
   GET http://localhost:8080/admin/dashboard
   Header: Authorization: Bearer <your-jwt-token>
   ```

## License
This project is free to use and modify.
